<?php
/**
 * User preferences form
 */

declare(strict_types=1);

namespace PhpMyAdmin\Config\Forms\Page;

class ImportForm extends \PhpMyAdmin\Config\Forms\User\ImportForm
{
}
